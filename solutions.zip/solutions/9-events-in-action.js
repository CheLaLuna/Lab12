export default () => {
  // BEGIN
const tabRows = Array.from(document.querySelectorAll('.row'));

tabRows.forEach(row => {
  const tabList = Array.from(row.querySelectorAll('[role="tab"]'));

  const handleClickOnTab = event => {
    const currentTab = event.target;
    const activeNavLink = row.querySelector('.nav-link.active');
    const activeTabPane = row.querySelector('.tab-pane.active');
    const targetTabPane = row.querySelector(currentTab.dataset.bsTarget);

    activeNavLink.classList.remove('active');
    activeTabPane.classList.remove('active');
    targetTabPane.classList.add('active');
    currentTab.classList.add('active');
  };

  tabList.forEach(tab => {
    tab.addEventListener('click', handleClickOnTab);
  });
});
  // END
};
