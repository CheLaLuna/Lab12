// BEGIN
export function text(fragment){
    const content = fragment.querySelectorAll('p');
    const array = Array.from(content);
    const newContent = array.map(content => content.textContent.trim())
    return newContent;
};
export default text;
// END