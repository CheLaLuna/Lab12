import prettify from './6-tree-manipulating.js';

prettify(document);