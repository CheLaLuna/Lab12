// BEGIN
export function browserInfo(browserUrl){
    const fullInfo = navigator.userAgent.split(' ')[0].split('/');
    const browserName = fullInfo[0];
    const browserVersion = fullInfo[1];
    return `${browserName}/${browserVersion} ${browserUrl}`;
}
export default browserInfo;
// END