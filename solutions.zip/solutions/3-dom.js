// BEGIN
function makeBeautiful(){
    const site = document.querySelector('body');
    const content = site.innerHTML;
    const lines = content.trim().split('\n');
    let newVersion = '';
    lines.forEach(line => {
        const newLine = document.createElement('p');
        newLine.textContent = line;
        newVersion += newLine.outerHTML;
    });
    site.innerHTML = newVersion;
};
makeBeautiful();
// END