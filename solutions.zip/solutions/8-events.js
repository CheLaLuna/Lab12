export default () => {
  // BEGIN
  const alertGenerator = document.querySelector('#alert-generator');
  const alertsContainer = document.querySelector('.alerts');
  let alertsCount = 1;

  alertGenerator.addEventListener('click', function() {
      const newDiv = document.createElement('div');
      newDiv.classList.add('alert', 'alert-primary');
      newDiv.textContent = `Alert ${alertsCount++}`;

      alertsContainer.insertBefore(newDiv, alertsContainer.firstChild);
  }); 
  // END
};