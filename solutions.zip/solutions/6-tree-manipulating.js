// BEGIN
export function prettify(document) {
    const divElements = document.querySelectorAll('div');
    divElements.forEach(divElement => {
        Array.from(divElement.childNodes)
        .filter(node => node instanceof Text && node.nodeValue.trim() !== '')
        .forEach(textNode => {
          const pElement = document.createElement('p');
          pElement.textContent = textNode.nodeValue;
          textNode.replaceWith(pElement);
        });
    });
}
export default prettify;
// END