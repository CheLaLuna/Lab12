import camelCase from 'lodash/camelCase';

// BEGIN
export function camelClassName(document){
    const names = document.getElementsByTagName('*');
    for (const name of names) {
        const classes = Array.from(name.classList);
        for (const kebab of classes) {
            const camel = camelCase(kebab);
            name.classList.replace(kebab, camel)
        }
    }
};
export default camelClassName;
// END