import escapeHtml from 'escape-html';

// BEGIN
export function escapeData() {
    const formOfFeedback = document.querySelector('.feedback-form');
    formOfFeedback.addEventListener('submit', (e) => {
        e.preventDefault();

        const dataEmail = escapeHtml(e.target.elements.email.value);
        const dataName = escapeHtml(e.target.elements.name.value);
        const dataComment = escapeHtml(e.target.elements.comment.value);

        const feedback = document.createElement('div');
        feedback.innerHTML = 
            <><p>Feedback has been sent</p><div>Email: ${dataEmail}</div><div>Name: ${dataName}</div><div>Comment: ${dataComment}</div></>
        ;

        formOfFeedback.parentNode.replaceChild(feedback, formOfFeedback);
    });
};
export default escapeData;
// END