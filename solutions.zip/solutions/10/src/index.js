import app from './application.js';

app();
